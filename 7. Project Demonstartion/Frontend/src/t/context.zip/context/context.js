import React from 'react'

const Context = React.createContext({

})

export default Context