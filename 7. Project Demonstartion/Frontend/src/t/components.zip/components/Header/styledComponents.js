// import styled from 'styled-components';

// export const NavBar = styled.nav`
// background-color: ${props => (props.dark ? "#333" : "#fff")};
// color: ${props => (props.dark ? "#fff" : "#333")};
// display: flex;
// justify-content: space-between;
// align-items: center;
// height:10vh;
// padding:0 20px;
// position:fixed;
// width:100%;
// `;

// export const NavItems = styled.ul`
// list-style: none;
// display: flex;
// gap: 20px;
// margin: 0;
// padding: 0;
// `;

// export const NavItem = styled.li`
// a {
//   color: inherit;
//   text-decoration: none;
//   font-weight: bold;
//   transition: color 0.3s;

//   &:hover {
//     color: #007bff;
//   }
// }
// `;
